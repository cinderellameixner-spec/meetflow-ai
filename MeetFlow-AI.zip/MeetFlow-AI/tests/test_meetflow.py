import io
import json
import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import app
import evaluate
import meetflow as mf

EXAMPLE = json.loads((app.ROOT / "sample.json").read_text("utf-8"))


def response(content):
    body = {"choices": [{"finish_reason": "stop", "message": {"content": content}}]}
    return io.BytesIO(json.dumps(body).encode())


class ProcessingTests(unittest.TestCase):
    def test_only_enabled_installation_can_read_host_key(self):
        with TemporaryDirectory() as folder, patch.dict(os.environ, DEEPSEEK_API_KEY="test-host-key"):
            root = Path(folder).resolve()
            with patch.object(mf, "PROJECT_ROOT", root):
                marker = root / "private/local-key-root.txt"
                marker.parent.mkdir()
                for copied in (False, True):
                    if copied:
                        marker.write_text(str(root.parent), "utf-8")
                    with patch.object(mf.os, "getenv", side_effect=AssertionError("host key lookup")):
                        self.assertEqual(app.status(), {"configured": False})
                        with self.assertRaises(mf.AnalysisError):
                            mf.resolve_key("")
                        self.assertEqual(mf.resolve_key("visitor"), "visitor")
                marker.write_text(str(root), "utf-8")
                self.assertEqual(app.status(), {"configured": True})
                self.assertEqual(mf.resolve_key(""), "test-host-key")
                self.assertEqual(mf.resolve_key("visitor"), "visitor")

    def test_sample_schema_and_evidence(self):
        self.assertEqual(mf.validate(EXAMPLE["summary"], "summary", EXAMPLE["text"]), EXAMPLE["summary"])
        self.assertEqual(mf.validate(EXAMPLE, "tasks", EXAMPLE["text"])["tasks"], EXAMPLE["tasks"])
        self.assertTrue(any(t["owner"] is None for t in EXAMPLE["tasks"]))

    def test_cannot_invent_quote(self):
        with self.assertRaises(mf.InvalidOutput):
            mf.validate(EXAMPLE, "tasks", "另一场会议。")

    def test_bad_payload(self):
        self.assertEqual(app.handle_analysis(b"not json")[0], 400)
        self.assertEqual(app.handle_analysis(b'{"text":"  "}')[0], 422)

    def test_key_required(self):
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": ""}), patch.object(mf, "urlopen") as send:
            self.assertEqual(app.handle_analysis(b'{"text":"meeting"}')[0], 422)
            send.assert_not_called()

    def test_response_retry_and_json_fence(self):
        data = json.dumps({"tasks": []})
        with patch.object(mf, "urlopen", side_effect=[response(" "), response("```json\n"+data+"\n```")]) as send, patch.object(mf.time, "sleep"):
            result = mf.request_json(mf.TASKS, "已完成。", "tasks", "已完成。", "test")
        self.assertEqual(result, {"tasks": []})
        self.assertEqual(send.call_count, 2)
        self.assertEqual(json.loads(send.call_args.args[0].data)["model"], mf.MODEL)

    def test_auth_no_retry(self):
        err = mf.HTTPError(mf.ENDPOINT, 401, "unauthorized", {}, None)
        with patch.object(mf, "urlopen", side_effect=err) as send, self.assertRaises(mf.AnalysisError):
            mf.request_json(mf.TASKS, "text", "tasks", "text", "test")
        self.assertEqual(send.call_count, 1)

    def test_retry_limit(self):
        with patch.object(mf, "urlopen", side_effect=OSError()) as send, patch.object(mf.time, "sleep"):
            with self.assertRaises(mf.AnalysisError):
                mf.request_json(mf.TASKS, "x", "tasks", "x", "test")
        self.assertEqual(send.call_count, 3)

    def test_long_meeting_consolidates(self):
        text = EXAMPLE["text"] + "以上是前期情况。" * 1100 + "补充：取消回滚清单。"
        calls = []
        def fake(prompt, data, kind, source, key):
            calls.append((prompt, data))
            if kind == "summary":
                return EXAMPLE["summary"]
            if prompt == mf.MERGE_TASKS:
                self.assertEqual(json.loads(data)["transcript"], text)
                return {"tasks": []}
            if prompt == mf.CROSSCHECK:
                self.assertEqual(json.loads(data)["tasks"], [])
                return {"tasks": []}
            return {"tasks": EXAMPLE["tasks"]}
        result = mf.analyze(text, "test", fake)
        self.assertGreater(result["chunks"], 1)
        self.assertEqual(len(calls), result["chunks"] * 2 + 3)
        self.assertEqual(result["tasks"], [])

    def test_http_entry_point(self):
        class Stream:
            def __init__(self, data):
                self.source = io.BytesIO(data)
                self.output = bytearray()
            def makefile(self, *args):
                return self.source
            def sendall(self, data):
                self.output.extend(data)

        def run_request(raw):
            stream = Stream(raw)
            app.LocalHandler(stream, ("127.0.0.1", 42), None)
            return bytes(stream.output)
        with patch.object(app.LocalHandler, "log_message"):
            home = run_request(b"GET / HTTP/1.0\r\nHost: localhost\r\n\r\n")
            self.assertIn(b"200 OK", home)
            self.assertIn(b"mountMeetFlow();", home)
            self.assertNotIn(b"__MEETFLOW_SAMPLE__", home)
            body = json.dumps({"text": EXAMPLE["text"], "key": "test"}).encode()
            request = b"POST /api/analyze HTTP/1.0\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body
            def provider(req, timeout):
                kind = json.loads(req.data)["messages"][0]["content"]
                value = EXAMPLE["summary"] if kind == mf.SUMMARY else {"tasks": EXAMPLE["tasks"]}
                return response(json.dumps(value))
            with patch.object(mf, "urlopen", side_effect=provider):
                result = json.loads(run_request(request).split(b"\r\n\r\n", 1)[1])
            self.assertEqual(result["tasks"], EXAMPLE["tasks"])
            self.assertEqual(result["summary"], EXAMPLE["summary"])


class EvaluationTests(unittest.TestCase):
    def reviewed(self):
        return {"id":"a", "gold_tasks":["A","B"],"result":{"tasks":[{},{}]},
                "ratings":dict(coverage=5, fidelity=4, conciseness=4, readability=3),
                "matches":[[1,1]], "elapsed_s":2.1}

    def test_metrics_include_failures(self):
        result = evaluate.score([self.reviewed(), {"id":"b","gold_tasks":["C"],"result":None}])
        self.assertEqual((result["TP"],result["FP"],result["FN"]), (1,1,2))
        self.assertAlmostEqual(result["recall"], 1/3)
        self.assertEqual(result["precision"], .5)
        self.assertEqual(result["weighted_summary_score"], 4.2)
        self.assertEqual(result["final_format_pass_rate"], .5)
        self.assertFalse(result["all_meetings_under_3s"])

    def test_reject_duplicate_matches(self):
        row = self.reviewed()
        row["matches"] = [[1,1],[1,2]]
        with self.assertRaises(ValueError):
            evaluate.score([row])

