import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import analysis_cache
import app
import meetflow
import workspace


class IncrementalTests(unittest.TestCase):
    def test_merge_starts_before_other_branch_finishes(self):
        merged=threading.Event()
        published=[]
        summary={"title":"会","overview":"讨论","decisions":[],"open_questions":[]}

        def provider(prompt, data, kind, source, key):
            if kind=="summary":
                if prompt==meetflow.MERGE_SUMMARY:
                    self.assertEqual(json.loads(data)["summaries"],[summary,summary])
                return summary
            if kind=="tasks":
                self.assertTrue(merged.wait(2))
            return {"tasks":[]}

        def publish(kind, result):
            published.append(kind)
            if kind=="summary":
                merged.set()

        with patch.object(meetflow,"split_text",return_value=["第一段","第二段"]):
            out=meetflow.analyze("第一段第二段","test",provider,on_ready=publish)
        self.assertEqual(published,["summary","tasks"])
        self.assertLessEqual(out["first_ready_s"],out["elapsed"])

    def test_stream_cache_force_and_saved_original(self):
        sample=json.loads((app.ROOT/"sample.json").read_text("utf8"))
        def provider(text, key, on_ready):
            on_ready("tasks",{"tasks":sample["tasks"]})
            on_ready("summary",sample["summary"])
            return dict(summary=sample["summary"],tasks=sample["tasks"],suggestions=[],elapsed=.5,chunks=1)

        def run(text,force=False):
            return [json.loads(line) for line in app.analysis_events(json.dumps(dict(text=text,force=force)).encode())]

        with tempfile.TemporaryDirectory() as d, patch.dict("os.environ",MEETFLOW_DB=str(Path(d)/"test.db")), patch.dict(analysis_cache._memory,clear=True), patch.object(app,"analyze",side_effect=provider) as model:
            text=sample["text"]
            self.assertEqual([e["event"] for e in run(text)],["tasks","summary","complete"])
            self.assertTrue(run(text)[0]["cached"])
            self.assertFalse(run(text,True)[-1]["cached"])
            self.assertEqual(model.call_count,2)
            # New meetings use the model output; the saved meeting keeps its edits.
            tasks=[dict(original=t,action="手动修订") for t in sample["tasks"]]
            saved=workspace.dispatch(dict(op="save",day="2026-11-22",text=text,summary=sample["summary"],tasks=tasks))
            analysis_cache._memory.clear()
            self.assertEqual(run(text)[0]["result"]["tasks"],sample["tasks"])
            self.assertEqual(saved["meeting"]["tasks"][0]["action"],"手动修订")
            self.assertFalse(run(text+" ")[-1]["cached"])
            with patch.object(analysis_cache,"_revision","another-revision"):
                self.assertFalse(run(text)[-1]["cached"])

    def test_incomplete_review_never_reused(self):
        with tempfile.TemporaryDirectory() as d, patch.dict("os.environ",MEETFLOW_DB=str(Path(d)/"test.db")), patch.dict(analysis_cache._memory,clear=True), patch.object(app,"analyze",return_value={"review_warning":"核对失败"}) as model:
            for _ in range(2):
                events=list(app.analysis_events(b'{"text":"meeting"}'))
                self.assertFalse(json.loads(events[-1])["cached"])
            self.assertEqual(model.call_count,2)
