import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError,URLError

import app
import batch
import meetflow as mf
import review_batch
from evaluate import WEIGHTS


def checked(action, owner, due, evidence, **extra):
    item=dict(action=action,owner=owner,due=due,evidence=evidence,**extra)
    return mf.validate({'tasks':[item]},'tasks',evidence)['tasks'][0]


class EvidenceChecks(unittest.TestCase):
    def test_owner_swap(self):
        s='Niko to own merging, Mark to quickly add forgotten auto traits'
        self.assertIsNone(checked('Merge the auto trait note','Mark',None,s)['owner'])
        self.assertEqual(checked('Merge the auto trait note','Niko',None,s)['owner'],'Niko')
        self.assertEqual(checked('Add forgotten auto traits','Mark',None,s)['owner'],'Mark')
        self.assertIsNone(checked('Merge note','Mark',None,'Mark to quickly add forgotten auto traits')['owner'])
    def test_missing_owner_and_deadline(self):
        s='上线前还要补一份回滚清单。'
        task=checked('补一份回滚清单','小林','周三',s)
        self.assertIsNone(task['owner']); self.assertIsNone(task['due'])
        self.assertEqual(len(task['review']),2)
    def test_event_and_due(self):
        s='December 22 -- activity to be decided on or by Dec 15'
        self.assertIsNone(checked('Decide activity',None,'December 22',s)['due'])
        self.assertEqual(checked('Decide activity',None,'Dec 15',s)['due'],'Dec 15')
    def test_invalid_field_quote(self):
        t=checked('发报告','林宁',None,'林宁：我来发报告。',owner_evidence='林宁：周二才发。')
        self.assertIsNone(t['owner'])
    def test_speaker_and_offsets(self):
        s='说明\n### 林宁：\n我周五前提交报告。'
        t=checked('提交报告','林宁','周五前',s)
        self.assertEqual(t['owner'],'林宁')
        for c in t['citations'].values():
            self.assertEqual(s[c['start']:c['end']],c['quote'])


class Connectivity(unittest.TestCase):
    def test_categories(self):
        for n,code in [(401,'auth'),(402,'balance'),(403,'permission'),(429,'rate'),(503,'service')]:
            with self.subTest(status=n),patch.object(mf,'urlopen',side_effect=HTTPError(mf.ENDPOINT,n,'',{},None)):
                self.assertEqual(app.handle_analysis(b'{"key":"demo"}','/api/check')[1]['code'],code)
    def test_network_and_success(self):
        with patch.object(mf,'urlopen',side_effect=URLError('down')):
            self.assertEqual(app.handle_analysis(b'{"key":"demo"}','/api/check')[1]['code'],'network')
        body=io.BytesIO(b'{"choices":[{"message":{"content":"OK"}}]}')
        with patch.object(mf,'urlopen',return_value=body) as send,patch.dict('os.environ',DEEPSEEK_API_KEY='fallback'):
            self.assertTrue(mf.test_connection('new-key')['verified'])
            self.assertEqual(send.call_args.args[0].get_header('Authorization'),'Bearer new-key')
    def test_batch_and_blind_review(self):
        with tempfile.TemporaryDirectory() as d,patch.object(batch,'OUT',Path(d)),patch.object(batch,'test_connection'),patch.object(batch,'analyze',return_value={'tasks':[],'summary':{}}):
            result=batch.start('zh','demo',True,False)
            self.assertEqual(result['success'],60)
            out=Path(result['folder'])
            for reviewer in ('评审A','评审B'):
                import csv
                p=out/(reviewer+'.csv')
                with p.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
                for r in rows:r.update(matches='[]',**dict.fromkeys(WEIGHTS,'4'))
                with p.open('w',encoding='utf-8-sig',newline='') as f:
                    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            scores=review_batch.collect_scores(out)
            self.assertEqual(scores['v3']['rated_summaries'],20)
            self.assertEqual(scores['v1']['weighted_summary_score'],4)
    def test_preflight_stops_batch(self):
        with tempfile.TemporaryDirectory() as d,patch.object(batch,'OUT',Path(d)),patch.object(batch,'test_connection',side_effect=mf.AnalysisError('网络失败','network')),patch.object(batch,'analyze') as send:
            result=batch.start('en','test',False,False)
            send.assert_not_called()
            self.assertEqual(result['done'],0)
            data=json.loads((Path(result['folder'])/'run.json').read_text('utf-8'))
            self.assertEqual(data['skipped'],20)

