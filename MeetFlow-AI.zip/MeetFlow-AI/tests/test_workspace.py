import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import app
import meetflow as mf
import workspace as ws
from review_actions import local_candidates, unseen


ROOT=Path(app.ROOT)
SAMPLE=json.loads((ROOT/"sample.json").read_text("utf8"))
SOURCES=ROOT/"MeetFlow-Benchmark-20"/"01_sources"


def source(mid):
    return next(SOURCES.glob(mid+"_*")).read_text("utf8")


def check(src,action,quote,owner=None,due=None,**extra):
    row=dict(action=action,evidence=quote,owner=owner,due=due,**extra)
    return mf.validate({"tasks":[row]},"tasks",src)["tasks"]


class PreviousRun(unittest.TestCase):
    def test_assignments_and_before_meeting_exclusion(self):
        ev="Mark to post comment on the PR"
        self.assertEqual(check(source("M04"),ev,ev)[0]["owner"],"Mark")
        s=source("M06")
        ev="Mark to move this content to a design note in the lang-team repo"
        self.assertEqual(check(s,"Move content of rust#44619 to a design note",ev)[0]["owner"],"Mark")
        self.assertFalse(check(s,"Update the project board","[ ] Update the project board with new RFCs"))

    def test_summary_supported_missing_actions(self):
        for mid,overview,expected in [
            ("M15","Next steps involve finding a group to continue the conversation.",None),
            ("M19","Decide the December 22 meeting topic on or by Dec 15.","Dec 15")]:
            with self.subTest(mid=mid):
                s=source(mid)
                summary=dict(title=mid,overview=overview,decisions=[],open_questions=[])
                candidates=local_candidates(s,summary,[],mf.validate)
                self.assertEqual(len(candidates),1)
                self.assertEqual(candidates[0]["due"],expected)
                ref=candidates[0]["citations"]["action"]
                self.assertEqual(s[ref["start"]:ref["end"]],ref["quote"])

    def test_nested_and_team_assignees(self):
        s=source("M05")
        ev=next(l.strip()[2:] for l in s.splitlines() if "Contact authors" in l)
        self.assertEqual(check(s,"Contact authors",ev)[0]["owner"],"Niko")
        for ev in ["Compiler team MCP to carve out the feature","Compiler team needs to do an audit"]:
            self.assertEqual(check(source("M13"),ev,ev)[0]["owner"],"Compiler team")

    def test_same_assignment_under_two_topics(self):
        s=source("M18")
        initial=check(s,"add notes","Mark to add notes","Mark")
        more=unseen(initial,local_candidates(s,SAMPLE["summary"],initial,mf.validate))
        self.assertEqual([t["citations"]["action"]["line"] for t in initial+more],[52,71])
        self.assertNotEqual(initial[0]["topic"],more[0]["topic"])

    def test_close_with_antecedent(self):
        t=check(source("M20"),"close","jup, will do")[0]
        self.assertEqual((t["action"],t["owner"]),("close lang-team#138","lcnr"))
        self.assertIn("should we close, lcnr?", t["evidence"])

    def test_wrong_summary_language(self):
        for mid in ("M05","M10","M16"):
            with self.subTest(mid=mid), self.assertRaisesRegex(mf.InvalidOutput,"overview"):
                mf.validate(SAMPLE["summary"],"summary",source(mid))

    def test_four_failed_sources_reject_bad_span_and_accept_exact_evidence(self):
        # The earlier failed calls did not retain the provider payload.
        for mid,fragment in [("M01","Felix to investigate"),("M03","Going to look for liaisons"),
                             ("M11","options for resolving the ambiguity"),("M12","Write this up")]:
            s=source(mid)
            line=next(l for l in s.splitlines() if fragment in l)
            with self.subTest(mid=mid):
                with self.assertRaisesRegex(mf.InvalidOutput,r"tasks\[0\].evidence"):
                    check(s,fragment,"this quotation was never in the source")
                self.assertEqual(check(s,fragment,line.strip())[0]["evidence"],line.strip())
                def response(quote):
                    payload=json.dumps({"tasks":[dict(action=fragment,evidence=quote)]})
                    return io.BytesIO(json.dumps({"choices":[{"finish_reason":"stop","message":{"content":payload}}]}).encode())
                attempts=[response("a missing quotation"),response(line.strip())]
                with patch.object(mf,"urlopen",side_effect=attempts) as send,patch.object(mf.time,"sleep"):
                    out=mf.request_json(mf.TASKS,s,"tasks",s,"test")
                self.assertEqual(out["tasks"][0]["evidence"],line.strip())
                feedback=json.loads(send.call_args.args[0].data)["messages"][-1]["content"]
                self.assertIn("tasks[0].evidence",feedback)

    def test_crosscheck_uses_source_and_keeps_proposal_out_of_decisions(self):
        s="A: Proposed changes: track requests. B: Send the notes tomorrow."
        summary=dict(title="Meeting",overview="Agreed to track requests.",decisions=["Track requests."],open_questions=[])
        def call(prompt,data,kind,src,key):
            if kind=="summary":
                return summary
            if kind=="tasks":
                return {"tasks":[]}
            self.assertEqual(json.loads(data)["transcript"],s)
            return mf.validate(dict(tasks=[dict(action="Send the notes",evidence="Send the notes tomorrow.")],
                decision_reviews=[dict(decision="Track requests.",evidence="Proposed changes: track requests.")],
                corrected_overview="Tracking requests was proposed."),"review",s)
        result=mf.analyze(s,"test",call)
        self.assertEqual(result["tasks"],[])
        self.assertEqual(len(result["suggestions"]),1)
        self.assertEqual(result["summary"]["decisions"],[])
        self.assertIn("proposed",result["summary"]["overview"])


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        env=patch.dict("os.environ",MEETFLOW_DB=str(Path(tmp.name)/"history.db"))
        env.start()
        self.addCleanup(env.stop)
        self.payload=dict(op="save",day="2026-11-16",text=SAMPLE["text"],summary=SAMPLE["summary"],
                          tasks=[dict(original=t) for t in SAMPLE["tasks"]])
    def test_history_duplicate_and_edits_survive_reopen(self):
        m=ws.dispatch(self.payload)["meeting"]
        ws.dispatch(dict(self.payload,day="2026-11-17"))
        t=m["tasks"][1]
        self.assertEqual(t["deadline"],"2026-11-19")
        patch_task=dict(op="update",id=t["id"],revision=0,change=dict(owner="本人",due="明天",deadline="2026-11-17",completed=True))
        ws.dispatch(patch_task)
        self.assertTrue(ws.dispatch(self.payload)["existing"])
        self.assertEqual(len(ws.dispatch(dict(op="list"))["meetings"]),2)
        t=ws.dispatch(dict(op="open",id=m["id"]))["meeting"]["tasks"][1]
        self.assertTrue(t["completed"])
        self.assertEqual(t["original"]["owner"],"陈晨")
        self.assertEqual(t["owner"],"本人")
        with self.assertRaisesRegex(mf.AnalysisError,"另一页面"):
            ws.dispatch(patch_task)
        m=ws.dispatch(dict(patch_task,revision=1,change=dict(completed=False)))["meeting"]
        self.assertFalse(m["tasks"][1]["completed"])
        self.assertEqual(len(ws.dispatch(dict(op="search",q="12 位同学"))["ids"]),2)

    def test_reminder_ack_reschedule_and_suggestion(self):
        self.payload["tasks"][0]["state"]="suggested"
        t=ws.dispatch(self.payload)["meeting"]["tasks"][0]
        def change(**fields):
            return ws.dispatch(dict(op="update",id=t["id"],revision=t["revision"],change=fields))["meeting"]["tasks"][0]
        t=change(state="active")
        t=change(ack=True)
        self.assertEqual(t["seen"],ws.alarm(t))
        t=change(deadline="2026-12-01")
        self.assertFalse(t["seen"])
        self.assertEqual(ws.alarm(t),"2026-12-01T09:00")
        t=change(reminder="off")
        self.assertFalse(ws.alarm(t))

    def test_atomic_save_and_date_rules(self):
        self.payload["tasks"][-1]["action"]=""
        with self.assertRaises(mf.AnalysisError):
            ws.dispatch(self.payload)
        self.assertFalse(ws.dispatch(dict(op="list"))["meetings"])
        for due,expected in [("明天下午三点前","2026-11-17"),("下周一","2026-11-23"),
                             ("Dec 15","2026-12-15"),("尽快",""),("2月30日","")]:
            self.assertEqual(ws.calendar_day(due,"2026-11-16"),expected)

