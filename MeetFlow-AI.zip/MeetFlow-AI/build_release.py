"""Build the distributable from public project files only."""
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
APP_FILES = """
app.py meetflow.py analysis_cache.py grounding.py workspace.py review_actions.py
evaluate.py batch.py review_batch.py compare_review.py build_release.py requirements.txt README.md
index.html ui.html ui.js workspace.js style.css sample.json start_meetflow.cmd 填写Key并测试.cmd
.gitignore benchmark/README.md benchmark/zh_holdout.jsonl benchmark/validation.csv
MeetFlow-Benchmark-20/sources.csv MeetFlow-Benchmark-20/02_inputs/meetings.jsonl
MeetFlow-Benchmark-20/04_review/reference_probes.jsonl
""".split()


def build():
    files = [ROOT / name for name in APP_FILES]
    files += sorted((ROOT / "tests").glob("test_*.py"))
    corpus = ROOT / "MeetFlow-Benchmark-20"
    files += sorted((corpus / "01_sources").glob("M[0-9][0-9]_*.md"))
    files += [corpus / "licenses" / name for name in ("LICENSE-APACHE", "LICENSE-MIT")]
    with NamedTemporaryFile(dir=ROOT, suffix=".tmp", delete=False) as temp:
        pending = Path(temp.name)
    try:
        with ZipFile(pending, "w", ZIP_DEFLATED) as archive:
            for path in files:
                archive.write(path, "MeetFlow-AI/" + path.relative_to(ROOT).as_posix())
        pending.replace(ROOT / "MeetFlow-AI.zip")
    finally:
        pending.unlink(missing_ok=True)


if __name__ == "__main__":
    build()
